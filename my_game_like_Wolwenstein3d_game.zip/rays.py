import numba.core.cpu_options
import pygame as pg
import math
from settings import *
from numba import njit
from numba import *
from functools import lru_cache


class Rays:
    def __init__(self, game):
        self.__game = game
        self.__angle = angle_of_wiev
        self.__angle_between_rays = angle_between_rays
        # self.__list_for_render = numba.types.List(numba.float32, numba.types.ABCMeta, numba.types.UniTuple(numba.float32, 2))
        self.__list_for_render = list()
        self.__num_of_rays = num_of_rays
        self.__scale = game_scale
        self.__max_depth = max_depth
        self.__screen_scale = screen_scale
        self.__screen_height = screen_height
        self.__half_of_screen_height = half_of_screen_height
        self.__texture = self.__game.renderer.dictionary_of_textures
        self.__texture_size = texture_size

    @property
    def return_list_for_rendering(self):
        return self.__list_for_render

    @return_list_for_rendering.setter
    def return_list_for_rendering(self, value):
        # self.__list_for_render.augment(value)
        self.__list_for_render.append(value)

    #  Способ роботы с лучами по типу сеточки
    #  Экран разделяется горизонтальными и вертикальными полосами с привзской по координатам
    def ray_cast(self):
        self.__list_for_render.clear()
        angle = self.__game.player.angle - self.__angle / 2
        x, y = self.__game.player.pos
        for ray in range(self.__num_of_rays):
            texture_vert = texture_hor = 0
            sina = math.sin(angle)
            cosa = math.cos(angle)
            # Вертикальные линии
            # Тут следует обрать внимание что в случае скругление в малую сторону надо отнимать 1 * 10 (-6)
            # это сделано для того чтобы мы проверяли следующий блок на предмет столновения с лучом
            # Короче находим коориданаты столновения луча с границами блока и длину луча
            # попутно получаем шаг по оси х
            x_vert, step_x = (math.ceil(x), 1) if cosa > 0 else (int(x) - 1e-6, -1)
            depth_vert = (x_vert - x) / cosa
            y_vert = y + (depth_vert * sina)
            # Теперь получаем шаг для луча и шаг по оси у
            depth_step = step_x / cosa
            step_y = depth_step * sina
            # А теперь прогоням с циклом по блокам, до масимальной дальности отрисовки луча (в нашем случаее 20 блоков)
            # В случае если по указанным координатам есть блок то прерываем цикл и идем дальше
            for vert_lines in range(self.__max_depth):
                tile = (int(x_vert), int(y_vert))
                if tile in self.__game.map.dictionary_of_map:
                    texture_vert = self.__game.map.dictionary_of_map[tile]
                    break
                # В случаее если блока нету то прибавляем нашим координатам и длине луча - наши смещения
                x_vert += step_x
                y_vert += step_y
                depth_vert += depth_step
            #Горизонтальные линии
            # Проделываем все тоже самое но теперь для горизотнтальных линий
            y_hor, step_y = (math.ceil(y), 1) if sina > 0 else (int(y) - 1e-6, -1)
            depth_hor = (y_hor - y) / sina
            x_hor = x + (depth_hor * cosa)
            depth_step = step_y / sina
            step_x = (depth_step * cosa)
            for hor_lines in range(self.__max_depth):
                tile = (int(x_hor), int(y_hor))
                if tile in self.__game.map.dictionary_of_map:
                    texture_hor = self.__game.map.dictionary_of_map[tile]
                    break
                x_hor += step_x
                y_hor += step_y
                depth_hor += depth_step
            #  А теперь сверяем длину лучей по горизонтальным и вертикальным поверхностям и выбираем найменьшую
            depth, offset, texture = (depth_hor, x_hor % 1, texture_hor) if depth_vert > depth_hor else (depth_vert, y_vert % 1, texture_vert)

            #  Отрисовываем наш луч для дебагинга
            # pg.draw.line(self.game.screen, 'yellow', (self.game.player.scaled_pos),
            #              ((x + depth * cosa) * self.__scale, (y + depth * sina) * self.__scale), 2)

            #  Удаляем эфект рыбьего глаза
            #  Тут все очень просто, надо при построении лучей падающий под разными углами у нас получится
            #  разные растояния
            #  но меняя наш угол нам бы следовало отталкиватся от того на жкране должно все отображатся одинаково
            #  поэтому мы переопределяем длину луча - на длину нашего "центрального луча" словно рисуем сектор дуги
            depth *= math.cos(self.__game.player.angle - angle)
            #  чтобы избежать зависания когда depth == 0
            depth = max(depth, 0.00001)

            #  Отрисовываем стену без текстур  для дебагинга
            #  Я лично исхожу из того принципа что чем больше наша длина луча тем кусок стены что отрисовывается меньше
            #  Поэтому я просто введу коофициэент маштабирования который буду делить на длину луча
            #  и умножать полученный результат на коофициэнт нашего игрового маштаба
            #  Из-за того когда мы близко подходим к стене, у нас сильно увеличивается изображения и начинает подлагивать
            #  это происходит из-за того что высота стены сильно растягивается
            #  поэтому используя функцию min
            # wall_height = min(int((11.5 / depth) * self.__scale), self.__half_of_screen_height * 4)
            wall_height = (11.5 / depth) * self.__scale

            # c = 100 - (20 + (80 / self.__max_depth) * depth)
            #
            # pg.draw.rect(self.game.screen, (c, c, c), (ray * self.__screen_scale,
            #                                          (self.__screen_height - wall_height) // 2, self.__screen_scale, wall_height))

            #  работаем с текстурами:
            if wall_height < self.__screen_height:
                #  Вначале обрезаем нужный нам кусочек текстуры, так как имем значение точки куда упал лучик

                x_texture_position = self.__texture[texture].subsurface(offset * (texture_size - self.__screen_scale), 0, self.__screen_scale, self.__texture_size)
                #  маштубирем этот кусочек под высоту кусочка стены что мы рисуем
                x_texture_position = pg.transform.scale(x_texture_position, (self.__screen_scale, wall_height))
                #  это уже готовая координата для отрисовки нашего лоскутка толщиной равной маштабу экрана
                wall_pos = (ray * self.__screen_scale, self.__half_of_screen_height - (wall_height) // 2)
            #  Это условие и фактор маштабирования вводим на тот случай если подошли близко к стене чтобы не было багов
            #  и чтобы не лагало и было красиво
            else:
                scalling_factor = texture_size * self.__screen_height / wall_height
                x_texture_position = self.__texture[texture].subsurface(offset * (texture_size - self.__screen_scale), (texture_size / 2 - scalling_factor / 2), self.__screen_scale, scalling_factor)
                x_texture_position = pg.transform.scale(x_texture_position, (self.__screen_scale, self.__screen_height))
                wall_pos = (ray * self.__screen_scale, 0)
            #  добавляем все данные в списочек для подальшего рендеринга
            self.__list_for_render.append((depth, x_texture_position, wall_pos))

            #прибавляем разницу угла между лучами для получения значения растояния для слуедущего луча
            angle += self.__angle_between_rays

    def get_renderer(self):
        pass

    def update(self):
        self.ray_cast()

    def update_numba(self):
        self.raycasting_numba()

    def raycasting_numba(self):
        self.__list_for_render.clear()
        angle = self.__game.player.angle - self.__angle / 2
        x, y = self.__game.player.pos
        for ray in range(num_of_rays):
            depth, offset, texture, wall_height = raycasting_numba(angle, self.__game.player.angle, x, y, self.__game.map.dictionary_of_map_numba)
            if wall_height < self.__screen_height:
                x_texture_position = self.__texture[texture].subsurface(offset * (texture_size - self.__screen_scale), 0, self.__screen_scale, self.__texture_size)
                x_texture_position = pg.transform.scale(x_texture_position, (self.__screen_scale, wall_height))
                wall_pos = (ray * self.__screen_scale, self.__half_of_screen_height - (wall_height) // 2)
            else:
                scalling_factor = texture_size * self.__screen_height / wall_height
                x_texture_position = self.__texture[texture].subsurface(offset * (texture_size - self.__screen_scale), (texture_size / 2 - scalling_factor / 2), self.__screen_scale, scalling_factor)
                x_texture_position = pg.transform.scale(x_texture_position, (self.__screen_scale, self.__screen_height))
                wall_pos = ray * self.__screen_scale, 0
            self.__list_for_render.append((depth, x_texture_position, wall_pos))
            angle += self.__angle_between_rays


#  Для ускорения работы придется создать отдельную функцию для просчета лучей
@njit()
def raycasting_numba(angle, player_angle, x, y, dictionary_of_map):
    texture_vert = texture_hor = 0
    sina = math.sin(angle)
    cosa = math.cos(angle)
    # Вертикальные линии
    x_vert, step_x = (math.ceil(x), 1) if cosa > 0 else (int(x) - 1e-6, -1)
    depth_vert = (x_vert - x) / cosa
    y_vert = y + (depth_vert * sina)
    depth_step = step_x / cosa
    step_y = depth_step * sina
    for vert_lines in range(max_depth):
        tile = (int(x_vert), int(y_vert))
        if tile in dictionary_of_map:
            texture_vert = dictionary_of_map[tile]
            break
        x_vert += step_x
        y_vert += step_y
        depth_vert += depth_step
    # Горизонтальные линии
    y_hor, step_y = (math.ceil(y), 1) if sina > 0 else (int(y) - 1e-6, -1)
    depth_hor = (y_hor - y) / sina
    x_hor = x + (depth_hor * cosa)
    depth_step = step_y / sina
    step_x = (depth_step * cosa)
    for hor_lines in range(max_depth):
        tile = (int(x_hor), int(y_hor))
        if tile in dictionary_of_map:
            texture_hor = dictionary_of_map[tile]
            break
        x_hor += step_x
        y_hor += step_y
        depth_hor += depth_step
    depth, offset, texture = (depth_hor, x_hor % 1, texture_hor) if depth_vert > depth_hor else (
        depth_vert, y_vert % 1, texture_vert)

    wall_height = (11.5 / depth) * game_scale
    depth *= math.cos(player_angle - angle)
    depth = max(depth, 0.00001)
    return depth, offset, texture, wall_height