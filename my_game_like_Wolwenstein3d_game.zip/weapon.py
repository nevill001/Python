from collections import deque
import os
from settings import *
import pygame as pg
import time


class Weapon:
    def __init__(self, game):
        self.__game = game
        self.__animation = self.get_images()
        self.__weapon_pos = (half_of_screen_wight - self.__animation[0].get_width() // 2,
                             screen_height - self.__animation[0].get_height())
        self.__len_of_images = len(self.__animation)
        self._reload_trigger = False
        self.__animation_weapon_counter = 1
        self.__animation_speed = 10

    @staticmethod
    def get_images():
        images = deque()
        for filename in os.listdir(path_to_weapon):
            if os.path.isfile(path_to_weapon + '\\' + filename):
                img = pg.image.load(path_to_weapon + '\\' + filename).convert_alpha()
                img = pg.transform.scale(img, (390, 400))
                images.append(img)
        return images

    def update(self):
        if self._reload_trigger and self.__game.animation_counter % self.__animation_speed == 0:
            # self.__game.player.player_shot = False
            self.__animation.rotate(-1)
            self.__animation_weapon_counter += 1
            if self.__animation_weapon_counter > self.__len_of_images:
                self.__game.sound.shotgun.play()
                self._reload_trigger = False
                self.__game.player.player_shot = True
                self.__animation_weapon_counter = 1

    def draw(self):
        self.__game.screen.blit(self.__animation[0], self.__weapon_pos)


if __name__ == '__main__':
    pass
