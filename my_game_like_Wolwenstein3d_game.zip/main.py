import pygame as pg
import sys
from settings import *
from map import Map
from player import Player
from rays import Rays
from renderer import Renderer
from sprite_objets import Sprites
from weapon import Weapon
from pathfinder import PathFinding
from sound import Sound


class Game:
    # def __init__(self):
    #     pg.init()
    #     self.res = screen_wight, screen_height
    #     self.screen = pg.display.set_mode(self.res)
    #     self.clock = pg.time.Clock()
    #     self.new_game()
    #     self.delta_time = 1
    def __init__(self, menu, player_start_position, map):
        self.player_start_position = player_start_position
        self.path_to_map = map
        self.menu = menu
        self.screen = self.menu.return_screen
        self.clock = self.menu.return_clock
        self.new_game()
        self.delta_time = 1

    def new_game(self):
        pg.mouse.set_visible(False)
        self.map = Map(self, self.path_to_map)
        self.renderer = Renderer(self)
        self.rays = Rays(self)
        self.sprites = Sprites(self)
        self.animation_counter = 0
        self.player = Player(self)
        self.weapon = Weapon(self)
        self.path = PathFinding(self)
        self.sound = Sound(self)
        pg.mixer.music.play(-1)

    def update(self):
        self.animation_counter = self.animation_counter % 241
        self.animation_counter += 1
        # self.rays.update()
        self.rays.update_numba()
        self.sprites.update()
        self.player.update()
        self.renderer.update()
        self.weapon.update()
        #  Че за метод так и не понял, но без него не работает
        pg.display.flip()
        #  Без него тоже, это короче сколько милесекунд проходит после последнего вызова функции отрисовки
        #  заодно можно задать в скобочках лимит на количество каждор
        self.delta_time = self.clock.tick(fps)
        #  Выводит нам на окошечке - вместо надписи пайгейм - количество кадров в секунду
        pg.display.set_caption(f'{self.clock.get_fps() :.1f}')

    def draw(self):
        #  Для очистки экрана заливаем его черным цветом
        #  Как на меня тупо!!!!!
        #  Почему нету метода очистки экрана:???? Эй разрабы!!!! Млять
        self.screen.fill('black')
        self.renderer.draw()
        self.weapon.draw()
        # self.map.draw()s
        # self.player.draw()

    def run(self):
        #  Начинаем бесконечный цикл, но всетаки холст в Java Script по сосвременнее устроен, там отдельный метод есть...
        while True:
            for event in pg.event.get():
                if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                    pg.quit()
                    sys.exit()
            self.update()
            self.draw()


if __name__ == '__main__':
    pass
    # new_game = Game()
    # new_game.run()