import pygame as pg
from settings import *
import math
import os
from collections import deque
from numba import njit
from functools import lru_cache


class Sprites:
    def __init__(self, game):
        self.__game = game
        self.__map = self.__game.map.ecces_to_list_map
        self.__sprite_types = {
            'barrel_1': {
                'name': 'barrel_1',
                'npc': False,
                'statick': True,
                'animated': False,
                'image': path_to_sprites + '\\barrel_1.png',
                'radius': 0.2,
                'scale': 0.5,
                'shift': 0.6
            },
            'tree_1': {
                'name': 'tree_1',
                'npc': False,
                'statick': True,
                'animated': False,
                'image': path_to_sprites + '\\tree_1.png',
                'radius': 1,
                'scale': 6,
                'shift': -0.36
            },
            'tree_2': {
                'name': 'tree_2',
                'npc': False,
                'statick': True,
                'animated': False,
                'image': path_to_sprites + '\\tree_2.png',
                'radius': 1,
                'scale': 6,
                'shift': -0.4
            },
            'tree_3': {
                'name': 'tree_3',
                'npc': False,
                'statick': True,
                'animated': False,
                'image': path_to_sprites + '\\tree_3.png',
                'radius': 1,
                'scale': 6,
                'shift': -0.4
            },
            'brush_1': {
                'name': 'brush_1',
                'npc': False,
                'statick': True,
                'animated': False,
                'image': path_to_sprites + '\\brush_1.png',
                'radius': 0.3,
                'scale': 1,
                'shift': -0.01
            },
            'brush_2': {
                'name': 'brush_2',
                'npc': False,
                'statick': True,
                'animated': False,
                'image': path_to_sprites + '\\brush_2.png',
                'radius': 0.3,
                'scale': 1,
                'shift': -0.01
            },
            'brush_3': {
                'name': 'brush_3',
                'npc': False,
                'statick': True,
                'animated': False,
                'image': path_to_sprites + '\\brush_3.png',
                'radius': 0.3,
                'scale': 1,
                'shift': -0.01
            },
            'brush_4': {
                'name': 'brush_4',
                'npc': False,
                'statick': True,
                'animated': False,
                'image': path_to_sprites + '\\brush_4.png',
                'radius': 0.15,
                'scale': 1,
                'shift': -0.01
            },
            'brush_5': {
                'name': 'brush_5',
                'npc': False,
                'statick': True,
                'animated': False,
                'image': path_to_sprites + '\\brush_5.png',
                'radius': 0.15,
                'scale': 1,
                'shift': -0.01
            },
            'green_lite': {
                'name': 'green_lite',
                'npc': False,
                'statick': True,
                'animated': True,
                'range_of_animation': 10,
                'animation_time': 20,
                'image': path_to_sprites + '\\green_lite\\0.png',
                'radius': 0.2,
                'images': path_to_sprites + '\\green_lite\\',
                'scale': 0.8,
                'shift': 0.24
            },
            'brush_anim_1': {
                'name': 'brush_anim_1',
                'npc': False,
                'statick': True,
                'animated': True,
                'range_of_animation': 10,
                'animation_time': 20,
                'image': path_to_sprites + '\\brush_anim_1\\0.png',
                'radius': 0.3,
                'images': path_to_sprites + '\\brush_anim_1\\',
                'scale': 1,
                'shift': -0.01
            },
            'brush_anim_2': {
                'name': 'brush_anim_2',
                'npc': False,
                'statick': True,
                'animated': True,
                'range_of_animation': 10,
                'animation_time': 20,
                'image': path_to_sprites + '\\brush_anim_2\\0.png',
                'radius': 0.3,
                'images': path_to_sprites + '\\brush_anim_2\\',
                'scale': 1,
                'shift': -0.01
            },
            'coco_demon': {
                'name': 'coco_demon',
                'npc': True,
                'statick': False,
                'animated': True,
                'range_of_animation': 15,
                'animation_time': 40,
                'image': path_to_npc + '\\coco_demon\\0.png',
                'radius': 0.5,
                'speed': 5e-3,
                'attack_radius': 1,
                'teror_radius': 7,
                'animation': [
                    self.get_images(path_to_npc + '\\coco_demon\\statick\\'),
                    path_to_npc + '\\coco_demon\\attack\\',
                    path_to_npc + '\\coco_demon\\hit\\',
                    path_to_npc + '\\coco_demon\\death\\',
                    path_to_npc + '\\coco_demon\\walk\\'
                ],
                'health': 5,
                'demage': 5,
                'start_angle': math.pi,
                'scale': 0.7,
                'shift': -0.2
            },
            'soldier': {
                'name': 'soldier',
                'npc': True,
                'statick': False,
                'animated': True,
                'range_of_animation': 15,
                'animation_time': 40,
                'image': path_to_npc + '\\coco_demon\\0.png',
                'radius': 0.3,
                'speed': 1e-3,
                'attack_radius': 4,
                'teror_radius': 15,
                'animation': [
                    self.get_images(path_to_npc + '\\soldier\\statick\\'),
                    path_to_npc + '\\soldier\\attack\\',
                    path_to_npc + '\\soldier\\hit\\',
                    path_to_npc + '\\soldier\\death\\',
                    path_to_npc + '\\soldier\\walk\\'
                ],
                'health': 2,
                'demage': 7,
                'start_angle': math.pi,
                'scale': 0.7,
                'shift': 0.2
            },
            'tank_1': {
                'name': 'tank_1',
                'npc': True,
                'statick': False,
                'animated': True,
                'range_of_animation': 15,
                'animation_time': 200,
                'image': path_to_npc + '\\tank_1\\0.png',
                'radius': 1,
                'animation': [
                    path_to_npc + '\\tank_1\\statick\\',
                    path_to_npc + '\\tank_1\\attack\\',
                ],
                'start_angle': math.pi,
                'scale': 1.2,
                'shift': 0.2
            }
        }
        self.__sprite_dict = {
            101: 'barrel_1',
            102: 'brush_1',
            103: 'tree_1',
            104: 'brush_2',
            105: 'tree_2',
            106: 'brush_3',
            107: 'tree_3',
            108: 'brush_4',
            109: 'brush_5',
            201: 'brush_anim_1',
            202: 'green_lite',
            203: 'brush_anim_2',
            301: 'coco_demon',
            302: 'soldier'
        }
        #  Этот словарь нам нужен для не статичных спрайтов, тоесть парйтов которые можно обойти кругом
        self.__divider = math.pi / 8
        self.__sprite_types_statick = {
            math.cos(self.__divider * 15): 4,
            math.cos(0): 4,
            math.cos(self.__divider): 5,
            math.cos(self.__divider * 2): 5,
            math.cos(self.__divider * 3): 6,
            math.cos(self.__divider * 4): 6,
            math.cos(self.__divider * 5): 7,
            math.cos(self.__divider * 6): 7,
            math.cos(self.__divider * 7): 0,
            math.cos(self.__divider * 8): 0,
            math.cos(self.__divider * 9): 1,
            math.cos(self.__divider * 10): 1,
            math.cos(self.__divider * 11): 2,
            math.cos(self.__divider * 12): 2,
            math.cos(self.__divider * 13): 3,
            math.cos(self.__divider * 14): 3,
        }
        # self.__list_of_sprites = [
        #     SpriteObject(self.__game, self.__sprite_types['barrel_1'], (4.5, 5.5)),
        #     AnimatedSprite(self.__game, self.__sprite_types['green_lite'], (5.5, 4.5)),
        #     AnimatedSprite(self.__game, self.__sprite_types['green_lite'], (6.5, 4.5)),
        #     AnimatedSprite(self.__game, self.__sprite_types['green_lite'], (7.5, 4.5)),
        #     AnimatedSprite(self.__game, self.__sprite_types['green_lite'], (8.5, 4.5)),
        #     # SpriteObject(self.__game, self.__sprite_types['tree_1'], (15, 15))
        # ]
        # self.__list_of_npc = [
        #     SpriteObject(self.__game, self.__sprite_types['coco_demon'], (11.5, 4.5))
        # ]
        self.__list_of_sprites, self.__list_of_npc = self.get_sprite_map()
        self.__list_of_death_sprites = deque()
        self.__nearest_npc_in_sight = False
        self.npc_positions = {}
        self.objects_positions = {object.map_pos for object in self.__list_of_sprites}


    # @property
    # def ecces_to_list_of_sprite(self):
    #     return self.__list_of_sprites
    #
    # @ecces_to_list_of_sprite.setter
    # def ecces_to_list_of_sprite(self, value):
    #     self.__list_of_sprites.append(value)
    #
    # @property
    # def ecces_to_list_of_npc(self):
    #     return self.__list_of_npc
    #
    # @ecces_to_list_of_npc.setter
    # def ecces_to_list_of_npc(self, value):
    #     self.__list_of_npc.append(value)

    #  Вызывается при нажатии правой кноки мышки, список спрайтов у нас отсортированый по растроянию от ближних к дальшим
    #  Если проверка на попадание в зону видимости проходит, то цикл прерывается, чтобы небыло пробивания

    def shooting_npc(self):
        x, y = self.__game.player.pos
        depth = projectile_collision(self.__game.player.angle, x, y, self.__game.map.dictionary_of_map_numba)
        if self.__nearest_npc_in_sight:
            if self.__nearest_npc_in_sight._is_alive:
                self.__game.sound.npc_pain.play()
                self.__nearest_npc_in_sight._agressiv = True
                self.__nearest_npc_in_sight.check_hitting(depth)

    @staticmethod
    def cheker_type_of_string(string):
        try:
            number = int(float(string) * 1e3)
            return number
        except ValueError:
            return False

    def get_sprite_map(self):
        sprite_list = list()
        npc_list = list()
        for object_y, row in enumerate(self.__map):
            for object_x, value in enumerate(row):
                result = self.cheker_type_of_string(value)
                if result:
                    if result < 100:
                        self.__game.map.map_builder((object_x, object_y), result)
                    if 100 < result < 200:
                        sprite_list.append(
                            SpriteObject(
                                self.__game, self.__sprite_types[self.__sprite_dict[result]], (object_x + 0.5, object_y + 0.5)
                            )
                        )
                    elif 200 < result < 300:
                        sprite_list.append(
                            AnimatedSprite(
                                self.__game, self.__sprite_types[self.__sprite_dict[result]], (object_x + 0.5, object_y + 0.5)
                            )
                        )
                    elif 300 < result < 400:
                        npc_list.append(
                            NPC(
                                self.__game, self.__sprite_types[self.__sprite_dict[result]], (object_x + 0.5, object_y + 0.5)
                            )
                        )
        return sprite_list, npc_list

    def map_for_collision_sprites(self):
        result_list = list()
        for item in self.__list_of_sprites:
            pos = item.getting_pos_of_sprites()
            result_list.append(pos)
        for item in self.__list_of_npc:
            pos = item.getting_pos_of_sprites()
            result_list.append(pos)
        return result_list

    def circle_animation(self, name, value):
        index = self.__sprite_types_statick[value]
        return self.__sprite_types[name]['animation'][0][index]

    def animation(self, name, trigger, value):
        return self.__sprite_types[name]['animation'][trigger][value]

    def animation_list_len(self, name, trigger):
        return len(self.__sprite_types[name]['animation'][trigger])

    #  Ну тут все элементарано, отсеиваем спрайты без жизней
    #  А также получаем ближайшего к нам НПС
    #  КОРОЧЕ ОЧЕНЬ ВЫЖНЫЙ БЛОК!!
    #  ТУТ ВСЯ ЛОГИКА РАБОТЫ НПС, КАК ОНИ БУДУТ СЕБЯ ВЕСТИ, МОЖНО ЛИ ИХ УБИТЬ, И.Т.П.
    #  И даже если они атакуют то отнимаем у нас жизни
    def update(self):
        #  Если все спрайты мертвы то вызываем метод
        if not len(self.__list_of_npc):
            return self.check_win()
        depth = 25
        for index, npc in enumerate(self.__list_of_npc):
            #  Если мы убежали от противника то он перестает быть агрессивным
            # if npc._dist > 45:
            #     npc._agressiv = False
            #  Отсеиваем спрайты без жизней, перенося их в список с мертвецами
            if npc._health < 1:
                self.__game.sound.npc_death.play()
                object = self.__list_of_npc.pop(index)
                object._reloader_animation = True
                object._is_alive = False
                self.__list_of_death_sprites.append(object)
            #  Самый нам ближайший спрайт проверяется на попадание в поле видимости(не стоит ли он за стеной)
            elif npc._norm_dist < depth and npc.check_conditions():
                depth = npc._norm_dist
                self.__nearest_npc_in_sight = npc
            #  Если мы вошли в радиус атаки НПС
            if npc._dist < npc._attack_radius:
                npc._reloader_animation = True
                npc.animation_trigger = 1
                #  В определенные промежутки времени отнимаем у нас здоровье
                if self.__game.animation_counter % 80 == 0:
                    self.__game.sound.npc_shot.play()
                    self.__game.sound.player_pain.play()
                    self.__game.player._health -= npc._demage
                    self.__game.renderer.player_hit()
            #  Если мы вошли в радиус терора убицы или он меет флажок агрессивный(активируется в случае попадания по нему)
            elif npc._dist < npc._teror_radius or npc._agressiv:
                if not npc._reloader_animation:
                    npc._reloader_animation = True
                    npc.animation_trigger = 4
                next_pos = self.__game.path.get_path(npc.map_pos, self.__game.player.return_map_plaer_pos())
                next_x, next_y = next_pos
                if next_pos not in self.npc_positions and self.objects_positions:
                    angle = math.atan2(next_y + 0.5 - npc._sprite_y, next_x + 0.5 - npc._sprite_x)
                    npc._object_angle = angle
                    dx = math.cos(angle) * npc._speed * self.__game.delta_time
                    dy = math.sin(angle) * npc._speed * self.__game.delta_time
                    npc.wall_collision(dx, dy)
        # self.__list_of_npc = list(filter(lambda x: x._health > 0, self.__list_of_npc))
        # self.__list_of_npc = sorted(self.__list_of_npc, key=lambda t: t._norm_dist)

        for objects in self.__list_of_sprites:
            objects.update_numba()
        for objects in self.__list_of_npc:
            objects.update_numba()
        for objects in self.__list_of_death_sprites:
            objects.update_numba()

        #  ЕСЛИ МЕРТВЫХ СПРАЙТОВ БОЛЬШЕ 5 ТО ПЕРВУЮ ТУШКУ ИЗ СПИСКА УБИРАЕМ С ЭКРАНА
        if len(self.__list_of_death_sprites) > 5:
            self.__list_of_death_sprites.popleft()
        #  ТУТ МЫ ПОЛУЧАЕМ ПОЗИЦИИ ВСЕХ СПРАЙТОВ ДЛЯ ИЗБЕЖАНИЯ СТОЛКНОВЕНИЯ НПС ДРУГ С ДРУГОМ
        self.npc_positions = {npc.map_pos for npc in self.__list_of_npc}

    def check_win(self):
        self.__game.renderer.win()
        pg.display.flip()
        pg.time.delay(1500)


    @staticmethod
    def get_images(path):
        images = list()
        for file_name in os.listdir(path):
            if os.path.isfile(os.path.join(path, file_name)):
                img = pg.image.load(path + file_name).convert_alpha()
                images.append(img)
        return images


class SpriteObject:
    def __init__(self, game, object, pos):
        self.__game = game
        self._name = object['name']
        #  Получаем базовые значения из объекта, которые определяют тип спрайта
        self._npc = object['npc']
        self._statick = object['statick']
        self._animated = object['animated']
        #
        # self._x, self._y = pos
        #  Тут будут условия для разных типов спрайтов, и для анимированных спрайтов и НПС будет добавлены особые свойства
        #  Это сделано чтобы не создавать лишний класс
        if not self._statick:
            self._divider = math.pi / 8
            self._object_angle = object['start_angle']
            self._statick_animation = object['animation']
            #  Если объект не статичен, то анимация обхода всегда в приоритете
        #  Продолжаем добывать значения из словаря которые потребуются любому типу спрайта
        self._object = pg.image.load(object['image']).convert_alpha()
        self._radius = object['radius']
        self._scale = object['scale']
        self._shift = object['shift']
        #  Словарь закончился, получаем значения позиции спрайта
        self._sprite_x, self._sprite_y = pos
        #  А теперь получаем сопутствующие значения, необходимые нам для вычислений
        self._image_width = self._object.get_width()
        self._image_height = self._object.get_height()
        self._image_ratio = self._image_width / self._image_height
        self._dx, self._dy, self._theta, self._screen_x, self._dist, self._norm_dist = 0, 0, 0, 0, 0, 0
        self._screen_dist = screen_dist

    @property
    def map_pos(self):
        return int(self._sprite_x), int(self._sprite_y)

    def getting_pos_of_sprites(self):
        return self._sprite_x, self._sprite_y, self._radius

    #  Получаем базовые значения угла между спрайтом и игроком и растояния от игрока до спрайта для отображения српайта любого типа
    def getting_basik_values(self):
        self._player_x, self._player_y = self.__game.player.pos
        self._dx = self._sprite_x - self._player_x
        self._dy = self._sprite_y - self._player_y
        self._theta = math.atan2(self._dy, self._dx)
        #  Ищем длину растояния между спрайтом и игроком
        self._dist = math.hypot(self._dx, self._dy)

    def get_sprite(self):
        #  Ищем угол между углом направления взгляда игрока и спрайтом
        delta = self._theta - self.__game.player.angle
        #  Вот этой хуйни я не понимаю, зачем прибавлять у углу полный оборот вокруг своей оси
        #  Но без нее в указанных ситуациях не отображается спрайт - проверено....
        if (self._dx > 0 and self.__game.player.angle > math.pi) or (self._dx < 0 and self._dy < 0):
            delta += math.tau
        #  Сколько лучей поместится в этом угле....
        #  Короче ищем область ширины экрана где будет отображатся наш спрайт
        delta_rays = delta / angle_between_rays
        self._screen_x = (num_of_rays // 2 + delta_rays) * screen_scale
        #  Во избежаемя эфекта рыбьего взгляда, пересчитываем длину этого растояния относительно игрока
        #  В воображения отбрасиывае под прямым гулом от спрайта к линии вида игрока прямую, и ищем эту длину
        self._norm_dist = self._dist * math.cos(delta)
        #  проверяем если спрайт попадает в область отображения то отображаем его
        if -(self._image_width / 2) < self._screen_x < (screen_wight + self._image_width / 2) and self._norm_dist > 0.5:
            self.get_sprite_projection()

    def get_sprite_projection(self):
        #  Ищем отношение как если бы наш спрайт отображался на весь экран, точнее находился бы на том же растоянии
        scale_ratio = self._screen_dist / self._norm_dist * self._scale
        #  Получаем коофициэент маштабирования и маштабируем нашу картинку под него
        object_scale_width, object_scale_height = scale_ratio * self._image_ratio, scale_ratio
        image = pg.transform.scale(self._object, (object_scale_width, object_scale_height))
        #  Размещаем наш спрайт, попутно привязывая его по оси у
        sprite_half_width = object_scale_width // 2
        height_shift = object_scale_height * self._shift
        pos = self._screen_x - sprite_half_width, half_of_screen_height - object_scale_height // 2 + height_shift
        #  Теперь у нас есть смаштабированое растоянии до спрайта, сама картнка, и позиция по х и у для ее отображения
        #  В отличие от лучей тут картинка отрисовывается вся целиком
        self.__game.rays.return_list_for_rendering = (self._norm_dist, image, pos)

    def get_sprite_projection_cutting(self):
        scale_ratio = self._screen_dist / self._norm_dist * self._scale
        object_scale_width, object_scale_height = scale_ratio * self._image_ratio, scale_ratio
        if object_scale_height < screen_height:
            image = pg.transform.scale(self._object, (object_scale_width, object_scale_height))
            sprite_half_width = object_scale_width // 2
            height_shift = object_scale_height * self._shift
            pos = self._screen_x - sprite_half_width, half_of_screen_height - object_scale_height // 2 + height_shift
            #  Теперь у нас есть смаштабированое растоянии до спрайта, сама картнка, и позиция по х и у для ее отображения
            #  В отличие от лучей тут картинка отрисовывается вся целиком
            self.__game.rays.return_list_for_rendering = (self._norm_dist, image, pos)
        else:
            object_scale_height = screen_height
            # if object_scale_width > screen_wight:
            #     object_scale_width = screen_wight
            scalling_factor_y = self._image_height * screen_height / object_scale_height
            scalling_factor_x = self._image_width * screen_wight / object_scale_width
            image_1 = self._object.subsurface(0, (self._image_height - scalling_factor_y), self._image_width, self._image_height)

            image = pg.transform.scale(image_1, (object_scale_width, object_scale_height))
            sprite_half_width = object_scale_width // 2
            height_shift = object_scale_height * self._shift
            pos = self._screen_x - sprite_half_width, half_of_screen_height - object_scale_height // 2 + height_shift
            #  Теперь у нас есть смаштабированое растоянии до спрайта, сама картнка, и позиция по х и у для ее отображения
            #  В отличие от лучей тут картинка отрисовывается вся целиком
            self.__game.rays.return_list_for_rendering = (self._norm_dist, image, pos)

    def update(self):
        self.getting_basik_values()
        if not self._statick:
            #  Угол расположения игрока относительно угла "смотрения" спрайта
            relative_angle = ((self._object_angle - self._theta) // self._divider) * self._divider
            self._object = self.__game.sprites.circle_animation(self._name, relative_angle)
        self.get_sprite()

    def update_numba(self):
        theta, self._dist, dx, dy = getting_basik_values(self.__game.player.pos, self._sprite_x, self._sprite_y)
        if not self._statick:
            relative_angle = ((self._object_angle - theta) // self._divider) * self._divider
            self._object = self.__game.sprites.circle_animation(self._name, relative_angle)
        self._screen_x, self._norm_dist = get_sprite(theta, self.__game.player.angle, dx, dy, self._dist, self._image_width)
        if self._norm_dist:
            self.get_sprite_projection()

    @staticmethod
    def get_images(path):
        images = deque()
        for file_name in os.listdir(path):
            if os.path.isfile(os.path.join(path, file_name)):
                img = pg.image.load(path + file_name).convert_alpha()
                images.append(img)
        return images


class AnimatedSprite(SpriteObject):
    def __init__(self, game, object, pos):
        super().__init__(game, object, pos)
        self.__game = game
        self._animation_time = object['animation_time']
        self._range_of_start_animation = object['range_of_animation']
        self._images = self.get_images(object['images'])

    def update(self):
        super().getting_basik_values()
        self.animate()
        super().get_sprite()

    def update_numba(self):
        theta, self._dist, dx, dy = getting_basik_values(self.__game.player.pos, self._sprite_x, self._sprite_y)
        self.animate()
        self._screen_x, self._norm_dist = get_sprite(theta, self.__game.player.angle, dx, dy, self._dist,
                                                     self._image_width)
        if self._norm_dist:
            self.get_sprite_projection()

    def animate(self):
        caunter = self.__game.animation_counter
        if caunter % self._animation_time == 0 and self._dist < self._range_of_start_animation:
            self._images.rotate(-1)
            self._object = self._images[0]

    @staticmethod
    def get_images(path):
        images = deque()
        for file_name in os.listdir(path):
            if os.path.isfile(os.path.join(path, file_name)):
                img = pg.image.load(path + file_name).convert_alpha()
                images.append(img)
        return images


class NPC(SpriteObject):
    def __init__(self, game, object, pos):
        super().__init__(game, object, pos)
        self.__game = game
        self.__animation_trigger = 0
        self._reloader_animation = False
        self.__animation_animate_counter = 0
        self._is_alive = True
        self._animation_time = object['animation_time']
        self._health = object['health']
        self._demage = object['demage']
        self._attack_radius = object['attack_radius']
        self._teror_radius = object['teror_radius']
        self._agressiv = False
        self._speed = object['speed']
        self._mooving_scale = 7
        self.__animation = [
            self.get_images(object['animation'][1]),
            self.get_images(object['animation'][2]),
            self.get_images(object['animation'][3]),
            self.get_images(object['animation'][4])
        ]
        self.__range_of_start_animation = 3

    @property
    def animation_trigger(self):
        return self.__animation_trigger

    @animation_trigger.setter
    def animation_trigger(self, value):
        self.__animation_trigger = value

    @staticmethod
    def get_images(path):
        images = deque()
        for file_name in os.listdir(path):
            if os.path.isfile(os.path.join(path, file_name)):
                img = pg.image.load(path + file_name).convert_alpha()
                images.append(img)
        return images

    def update_numba(self):

        theta, self._dist, dx, dy = getting_basik_values(self.__game.player.pos, self._sprite_x, self._sprite_y)
        if self._is_alive:
            if not self._statick and not self.__animation_trigger and not self._reloader_animation:
                relative_angle = ((self._object_angle - theta) // self._divider) * self._divider
                result_angle = math.cos(relative_angle)
                self._object = self.__game.sprites.circle_animation(self._name, result_angle)
            else:
                self.animate()
        else:
            self.animate_dead()
        self._screen_x, self._norm_dist = get_sprite(theta, self.__game.player.angle, dx, dy, self._dist, self._image_width)
        if self._norm_dist:
            super().get_sprite_projection()

    def animate(self):
        if self._reloader_animation and self.__game.animation_counter % self._animation_time == 0:
            self._object = self.__animation[self.__animation_trigger - 1][0]
            self.__animation[self.__animation_trigger - 1].rotate(-1)
            self.__animation_animate_counter += 1
            if self.__animation_animate_counter > len(self.__animation[self.__animation_trigger - 1]):
                self._reloader_animation = False
                self.__animation_animate_counter = 1
                self.__animation_trigger = 0

    def animate_dead(self):
        if self._reloader_animation and self.__game.animation_counter % self._animation_time == 0:
            self._object = self.__animation[2][0]
            self.__animation[2].rotate(-1)
            self.__animation_animate_counter += 1
            if self.__animation_animate_counter > len(self.__animation[2]):
                self._reloader_animation = False
                self._shift += 0.2

    #  Это проверка сделана для того абы спрайты не простреливались друг через друга
    def check_conditions(self):
        if half_of_screen_wight - self._image_width / 2 < self._screen_x < half_of_screen_wight + self._image_width / 2:
            return True

    def check_hitting(self, depth):
        if depth > self._norm_dist:
            self._reloader_animation = True
            self.__animation_trigger = 2
            self._health -= 1

    def wall_collision(self, dx, dy):
        if self.__game.map.return_map_position_for_collision((int(self._sprite_x + dx * self._mooving_scale), int(self._sprite_y))):
            self._sprite_x += dx
        if self.__game.map.return_map_position_for_collision((int(self._sprite_x), int(self._sprite_y + dy * self._mooving_scale))):
            self._sprite_y += dy

    # def moovement(self):
    #     next_pos = self.__game.path.get_path(self.map_pos, self.__game.player.return_map_plaer_pos())
    #     return next_pos


@njit()
def projectile_collision(angle, x, y, dictionary_of_map):
    sina = math.sin(angle)
    cosa = math.cos(angle)
    # Вертикальные линии
    x_vert, step_x = (math.ceil(x), 1) if cosa > 0 else (int(x) - 1e-6, -1)
    depth_vert = (x_vert - x) / cosa
    y_vert = y + (depth_vert * sina)
    depth_step = step_x / cosa
    step_y = depth_step * sina
    for vert_lines in range(max_depth):
        tile = (int(x_vert), int(y_vert))
        if tile in dictionary_of_map:
            break
        x_vert += step_x
        y_vert += step_y
        depth_vert += depth_step
    # Горизонтальные линии
    y_hor, step_y = (math.ceil(y), 1) if sina > 0 else (int(y) - 1e-6, -1)
    depth_hor = (y_hor - y) / sina
    x_hor = x + (depth_hor * cosa)
    depth_step = step_y / sina
    step_x = (depth_step * cosa)
    for hor_lines in range(max_depth):
        tile = (int(x_hor), int(y_hor))
        if tile in dictionary_of_map:
            break
        x_hor += step_x
        y_hor += step_y
        depth_hor += depth_step
    depth = depth_hor if depth_vert > depth_hor else depth_vert
    depth = max(depth, 0.00001)
    return depth

# тоже ускорим роботу функции

@njit()
def getting_basik_values(player_pos, sprite_x, sprite_y):
    player_x, player_y = player_pos
    dx = sprite_x - player_x
    dy = sprite_y - player_y
    theta = math.atan2(dy, dx)
    dist = math.hypot(dx, dy)
    return theta, dist, dx, dy

@njit()
def get_sprite(theta, player_angle, dx, dy, dist, image_width):
    delta = theta - player_angle
    if (dx > 0 and player_angle > math.pi) or (dx < 0 and dy < 0):
        delta += math.tau
    delta_rays = delta / angle_between_rays
    screen_x = (num_of_rays // 2 + delta_rays) * screen_scale
    norm_dist = dist * math.cos(delta)
    if -(image_width / 2) < screen_x < (screen_wight + image_width / 2) and 0.5 < norm_dist < 25:
        return screen_x, norm_dist
    else:
        return False, False

# @njit()
# def get_sprite_projection(norm_dist, scale):
#     scale_ratio = screen_dist / norm_dist * scale
#     object_scale_width, object_scale_height = scale_ratio * self._image_ratio, scale_ratio
#     image = pg.transform.scale(self._object, (object_scale_width, object_scale_height))
#     sprite_half_width = object_scale_width // 2
#     height_shift = object_scale_height * self._shift
#     pos = self._screen_x - sprite_half_width, half_of_screen_height - object_scale_height // 2 + height_shift
#     self.__game.rays.return_list_for_rendering = (self._norm_dist, image, pos)


if __name__ == '__main__':
    pass