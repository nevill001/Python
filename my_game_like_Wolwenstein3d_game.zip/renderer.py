import math

import pygame as pg
from settings import *
from numba import njit


class Renderer:
    def __init__(self, game):
        self.__game = game
        self.__screen = self.__game.screen
        self.__textures = self.load_wall_textures()
        self.__sky_texture = self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'sky_texture.png', (screen_wight, half_of_screen_height))
        self.__win_image = self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'win.png', (screen_wight, screen_height))
        self.__game_over_image = self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'game_over.png', (screen_wight, screen_height))
        self.__blood_screen = self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'blood_screen.png', (screen_wight, screen_height))
        self.__digit_size = 60
        self.__digit_images = [self.get_texture(path_to_resources + f'\\textures\\digits\\{i}.png', [self.__digit_size] * 2)
                             for i in range(11)]
        self.__digits = dict(zip(map(str, range(11)), self.__digit_images))
        #
        self.__screen_wight = screen_wight
        self.__screen_height = screen_height
        self.__half_of_screen_height = half_of_screen_height
        self.__sky_offset = 0.5
        self.__previous_player_angle = 0
        self.__list_object = list()

    def draw_player_health(self):
        health = str(self.__game.player._health)
        for i, char in enumerate(health):
            self.__screen.blit(self.__digits[char], (i * self.__digit_size, 0))
        self.__screen.blit(self.__digits['10'], ((i + 1) * self.__digit_size, 0))

    def player_hit(self):
        self.__screen.blit(self.__blood_screen, (0, 0))

    def win(self):
        self.__screen.blit(self.__win_image, (0, 0))

    def game_over(self):
        self.__screen.blit(self.__game_over_image, (0, 0))

    @property
    def dictionary_of_textures(self):
        return self.__textures

    #  Статический метод так как тут не требуется доступ к объекту класса
    #  Мы просто загружаем текстурку и обрабатываем ее
    #  Возрращаем уже шкурку готовую для натягивания
    @staticmethod
    def get_texture(path, res=(texture_size, texture_size)):
        texture = pg.image.load(path).convert_alpha()
        return pg.transform.scale(texture, res)

    # Получаем путь и загружаем нашу текстурку
    def load_wall_textures(self):
        return {
            0: self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_0.png'),
            1: self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_1.png'),
            2: self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_2.png'),
            3: self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_3.png'),
            4: self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_4.jpg'),
            5: self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_5.jpg'),
            6: self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_6.jpg'),
            7: self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_7.png'),
        }

    def load_wall_textures_for_numba(self):
        return [
            self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_0.png'),
            self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_1.jpg'),
            self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_2.jpg'),
            self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_3.jpg'),
            self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_4.jpg'),
            self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_5.jpg'),
            self.get_texture(path_to_resources + '\\' + 'textures' + '\\' + 'texture_6.jpg')
        ]

    def render_game_objects(self):
        for depth, image, pos in self.__list_object:
            self.__screen.blit(image, pos)

    def render_game_objects_numba(self, list_objects):
        for depth, image, pos in list_objects:
            self.__screen.blit(image, pos)

    def draw_background(self):
        #  Рисуем пол
        pg.draw.rect(self.__screen, (0, 50, 0), (0, self.__half_of_screen_height, self.__screen_wight, self.__screen_height))
        #  Рисуем небо
        self.__sky_offset = (self.__sky_offset + 4 * self.__game.player.rel_for_mouse_control) % self.__screen_wight
        self.__screen.blit(self.__sky_texture, (-self.__sky_offset, 0))
        self.__screen.blit(self.__sky_texture, (-self.__sky_offset + self.__screen_wight, 0))
        # self.__sky_offset = -5 * math.degrees(self.__game.player.angle) % self.__screen_wight
        # self.__screen.blit(self.__sky_texture, (self.__sky_offset, 0))
        # self.__screen.blit(self.__sky_texture, (self.__sky_offset - self.__screen_wight, 0))
        # self.__screen.blit(self.__sky_texture, (self.__sky_offset + self.__screen_wight, 0))
        # self.__sky_offset = (self.__sky_offset + 4 * self.__game.player.angle) % self.__screen_wight
        self.__previous_player_angle = self.__game.player.angle

    def draw(self):
        self.draw_background()
        # self.render_game_objects()
        self.render_game_objects()
        self.draw_player_health()

    def update(self):
        self.__list_object = sorted(self.__game.rays.return_list_for_rendering, key=lambda t: t[0], reverse=True)

    def shooting_surface(self):
        for elem in self.__list_object[screen_wight // 4:]:
            if int(elem[2][0]) == screen_wight // 2:
                dist = elem[0]
                break


def quick_sort(array):
    if len(array) > 1:
        mid_elem = array.pop(len(array) // 2)
        l_list, m_list, r_list = list(), [mid_elem], list()
        for item in array:
            if item[0] == mid_elem[0]:
                m_list.append(item)
            elif item[0] < mid_elem[0]:
                l_list.append(item)
            else:
                r_list.append(item)
        return quick_sort(r_list) + m_list + quick_sort(l_list)
    else:
        return array

@njit()
def sorting_numba(array):
    return array.sorted(array, key=lambda t: t[0], reverse=True)


if __name__ == '__main__':
    print(quick_sort([3, 45, 67, 12, 0, 11]))