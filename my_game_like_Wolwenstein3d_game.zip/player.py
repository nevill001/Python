import pygame as pg
from settings import *
import math
from numba import njit
from functools import lru_cache


class Player:
    def __init__(self, game):
        self.__game = game
        self.__angle = player_angle
        # self.__x, self.__y = player_start_position
        self.__x, self.__y = self.__game.player_start_position
        self.__player_size_scale = player_size_scale
        self.__rel = 0
        self.__map_for_collision_stat_sprites = list()
        self.__player_radius = player_radius
        self.__speed_scale = 7
        self._health = player_health
        self.player_shot = True
        self._preruvatel = False
        self.i = 0
        # self.proverka = 0

    @property
    def rel_for_mouse_control(self):
        return self.__rel

    def return_map_plaer_pos(self):
        return int(self.__x), int(self.__y)

    @property
    def scaled_pos(self):
        return self.__x * 100, self.__y * 100

    @property
    def pos(self):
        return self.__x, self.__y

    @property
    def angle(self):
        return self.__angle

    def check_game_over(self):
        if self._health < 1:
            self.__game.renderer.game_over()
            pg.display.flip()
            pg.time.delay(1500)
            # self.__game.new_game()

    def recovery_health(self):
        if self._health < 100:
            if not self.__game.animation_counter % 240:
                self._health += 1

    def update(self):
        self.recovery_health()
        self.check_game_over()
        self.__map_for_collision_stat_sprites = self.__game.sprites.map_for_collision_sprites()
        self.mooving()
        self.mouse_control()

    def draw(self):
        # pg.draw.line(self.__game.screen, 'red', (self.scaled_pos),
        #              ((self.__x + (math.cos(self.__angle) * 2)) * game_scale, (self.__y + (math.sin(self.__angle) * 2)) * game_scale), 2)
        # pg.draw.circle(self.__game.screen, 'green', (self.scaled_pos), self.__player_size_scale)
        pass

    def check_map_wall(self, x, y):
        return (x, y) not in self.__game.map.dictionary_of_map

    def check_sprite_collision(self, dx, dy):
        check = True
        for item in self.__map_for_collision_stat_sprites:
            distance = distance_beetwen_two_points(item[0], item[1], self.__x + dx, self.__y + dy)
            if distance < item[2] + self.__player_radius:
                check = False
                break
        return check

    def check_wall_collision(self, dx, dy):
        check_with_item_collision = self.check_sprite_collision(dx, dy)
        if self.check_map_wall(int(self.__x + dx * self.__speed_scale), int(self.__y)) and check_with_item_collision:
            self.__x += dx
        if self.check_map_wall(int(self.__x), int(self.__y + dy * self.__speed_scale)) and check_with_item_collision:
            self.__y += dy

    def mooving(self):
        #  Я подсмотрел хитрый трюк маштабирования скорости перемещения!!
        #  Если скорость поворота и скорость перемещения сделать достаточно маленькими
        #  И каждый тик доумножать эту скорость на количество милесекунл прошедших с предудущего вызова функции отрисовки
        #  берется это значение из основного класа
        #  То на выходе при смене количества кадров в секунду мы почти не почуствуем разницы в скорости перемещения!!!!
        #  Конечно картинка станет дергатся, но скорость перемещения почти не изменится
        speed = player_speed * self.__game.delta_time
        rotate_speed = player_rotate_speed * self.__game.delta_time
        #  вначале задаем клавиши что будут поворачитвать нашего игрока
        #  Создаем отловщик события нажатие на клавиши
        key = pg.key.get_pressed()
        # if key[pg.K_LEFT]:
        #     self.__angle -= rotate_speed
        # if key[pg.K_RIGHT]:
        #     self.__angle += rotate_speed
        #Вводим переменные
        dx, dy = 0, 0
        cos_speed = speed * math.cos(self.__angle)
        sin_speed = speed * math.sin(self.__angle)
        #
        if key[pg.K_w]:
            dx += cos_speed
            dy += sin_speed
        if key[pg.K_s]:
            dx -= cos_speed
            dy -= sin_speed
        if key[pg.K_a]:
            dx += sin_speed
            dy -= cos_speed
        if key[pg.K_d]:
            dx -= sin_speed
            dy += cos_speed

        mouse_click = pg.mouse.get_pressed()
        if mouse_click[0] and self.player_shot:
            # self.i += 1
            # print(self.i)
            self.player_shot = False
            self.__game.weapon._reload_trigger = True
            self.__game.sprites.shooting_npc()



        #  Далее довольно объемный кусок кода!! Но не пугайтесь.. Это обработка столконовений, и выполняется только одна строчка!!!!
        #  Вначеле мы ищем подходящее условие чтобы наши растояние были с определенными знаками.
        #  Дело в том, что из-за того что наш игрок имеет размеры, нам прихожится учитывать размер блока игрока
        #  он задается в переменной self.__player_radius = 0.25
        #  когда условие одовлетворено, например dx < 0 and dy > 0 то выполняется метод класса Map =>  return_map_position_for_collision( )
        #  чтобы наш шарик не выходил за пределы, то мы соотвественно отнимае или прибавляем наш радиус (в зависимости от направления движения)
        #  Вот и все - все очено просто, а далее наш метод просто проверяет наши координаты и если они находся в "карте" то
        #  наш метод возвращает значение False
        # if dx > 0:
        #     if dy > 0:
        #         if self.game.map.return_map_position_for_collision((int(self.__x + dx + self.__player_radius), int(self.__y + dy + self.__player_radius))):
        #             self.__x += dx
        #             self.__y += dy
        #     else:
        #         if self.game.map.return_map_position_for_collision((int(self.__x + dx + self.__player_radius), int(self.__y + dy - self.__player_radius))):
        #             self.__x += dx
        #             self.__y += dy
        # else:
        #     if dy > 0:
        #         if self.game.map.return_map_position_for_collision(
        #                 (int(self.__x + dx - self.__player_radius), int(self.__y + dy + self.__player_radius))):
        #             self.__x += dx
        #             self.__y += dy
        #     else:
        #         if self.game.map.return_map_position_for_collision(
        #                 (int(self.__x + dx - self.__player_radius), int(self.__y + dy - self.__player_radius))):
        #             self.__x += dx
        #             self.__y += dy

        # Переписо обработчик столкновения со стеной
        # Просто передаем в метод наши значения перемещения
        self.check_wall_collision(dx, dy)

        #  !!!! Когда мы поворачиваемся вокруг своей оси то угл может возрастать и восзрать... до бесконечности
        #  Дело в том что полному обороту круга вокруг своей оси соответсвует 2 * pi радиан.
        #  В пайтоне в pygame используется радиальная система исчеслений
        #  Когда наш счетчит угла оборота достигент полного круга, то он поделится сам на себя без остатка...
        #  math.tau == math.pi * 2
        self.__angle = self.__angle % math.tau

    def mouse_control(self):
        mx, my = pg.mouse.get_pos()
        #  На случай ешли мы мышкой вышли за пределы границ, наша мышка возвращается в центр
        if mx > mouse_border_right or mx < mouse_border_left:
            pg.mouse.set_pos([half_of_screen_wight, half_of_screen_height])
        self.__rel = pg.mouse.get_rel()[0]
        #  Недаем значению mouse.rel (это что-то вроде разницы перемещения мышкой)
        #  выдается она в списке с помощью метода pg.mouse.get_rel() по х и у
        #  так вот строка ниже недает этому значени быть меньше чем -mouse_max_rel и больше чем mouse_max_rel
        self.__rel = max(-mouse_max_rel, min(mouse_max_rel, self.__rel))
        self.__angle += mouse_sensivity * self.__game.delta_time * self.__rel


@njit()
def distance_beetwen_two_points(a_x, a_y, b_x, b_y):
    distance = math.hypot(b_x - a_x, b_y - a_y)
    return distance