import pygame as pg
import math
from collections import deque


class PathFinding:
    def __init__(self, game):
        self.__game = game
        self._graf = {}
        self._ways = [-1, 0], [0, -1], [1, 0], [0, 1], [-1, -1], [1, -1], [1, 1], [-1, 1]
        self.get_graf()

    @staticmethod
    def cheker_type_of_string(string):
        if string == '_____':
            return True
        else:
            return False

    @staticmethod
    def cheker_type_of_number(string):
        try:
            number = int(float(string) * 1e3)
            return number
        except ValueError:
            return False

    def get_next_nodes(self, x, y):
        return [(x + dx, y + dy) for dx, dy in self._ways if (x + dx, y + dy) not in self.__game.map.ecces_to_wold_map]

    def get_graf(self):
        for y, row in enumerate(self.__game.map.ecces_to_list_map):
            for x, value in enumerate(row):
                result = self.cheker_type_of_string(value)
                result_2 = self.cheker_type_of_number(value)
                if result:
                    self._graf[(x, y)] = self._graf.get((x, y), []) + self.get_next_nodes(x, y)
                if result_2:
                    # if 300 < result_2 < 400:
                    self._graf[(x, y)] = self._graf.get((x, y), []) + self.get_next_nodes(x, y)

    def get_path(self, start, goal):
        self.visited = self.bfs(start, goal, self._graf)
        path = [goal]
        step = self.visited.get(goal, start)

        while step and step != start:
            path.append(step)
            step = self.visited[step]
        return path[-1]

    def bfs(self, start, goal, graph):
        queue = deque([start])
        visited = {start: None}

        while queue:
            cur_node = queue.popleft()
            if cur_node == goal:
                break
            next_nodes = graph[cur_node]

            for next_node in next_nodes:
                if next_node not in visited and next_node not in self.__game.sprites.npc_positions:
                    queue.append(next_node)
                    visited[next_node] = cur_node
        return visited


if __name__ == '__main__':
    pass