import numba
import pygame as pg
from settings import *
from numba.core import types
from numba.typed.typeddict import Dict
from numba import int16


#  Создаем класс карта, тут мы будем строить карту, отрисовывать ее, и манипулировать разными объектами на ней
class Map:
    #  !!!Обратите внимание!!!! в качестве аргемента при создании класса мы получаем другой класс!!!
    def __init__(self, game, path):
        self.__game = game
        self.__list_map = self.download_level_map(path)
        #  Записать наши координаты статичных объектов и какой объект на ней будем в словарик
        # так как мы будем использовать ускорение с помощью фрейморка numba
        #  а он не понимание ни классов ни словарей, то нам необходимо будет использовать специальные словари
        #  ключами в нем могут быть в нашем случае только целочисельные знаение в кортежах по 2 элемента в диапозоне int64
        self.__world_map_numba = Dict.empty(key_type=types.UniTuple(int16, 2), value_type=int16)
        self.__world_map = {}
        #  При создании класса сразу вызываем мето для заполнения нашего словарика


    def map_builder(self, pos, value):
        self.__world_map[pos] = value
        self.__world_map_numba[pos] = value

    @property
    def ecces_to_wold_map(self):
        return self.__world_map

    @property
    def ecces_to_list_map(self):
        return self.__list_map

    @staticmethod
    def cheker_type_of_string(string):
        try:
            number = int(float(string) * 1e3)
            return number
        except ValueError:
            return False

    @staticmethod
    def download_level_map(path):
        game_map = []
        with open(path, 'r') as file:
            src = file.readlines()
            for line in src:
                line = line[:-1]
                game_map.append(line.split(', '))
        return game_map

    def _get_map(self):
        #  Пробегаемся по нашему списку
        for map_y, row in enumerate(self.__list_map):
            for map_x, value in enumerate(row):
                result = self.cheker_type_of_string(value)
                if result:
                    if result < 100:
                        self.__world_map[(map_x, map_y)] = result
                        self.__world_map_numba[(map_x, map_y)] = result
        #  Например позиции с координами (0, 0) будет соответсвовать значение 1
        #  !!Обратите внимание что рядки нашего списка - это координаты по иксу, а рядки встроеных списков - по игреку!!!
        #  Также вы зададите вопрос а почему координаты будут максимум (12, 7), неужели такое маленье игровое поле???
        #  Нет - этот трюк - нам поможет очень просто обробатывать столкновения, об этом в файле player
        #  Мы будем проводить маштабирование нашего игрового поля равное маштабу в настройках, по умолчанию 100
        #  !!!!тоесть координате (0, 0) соответствует квадратик (с набором текстур 1) с началом координат от (0, 0) до (100, 100)   !!!!!

    def return_map_position_for_collision(self, pos):
        if pos in self.__world_map:
            return False
        else:
            return True

    @property
    def dictionary_of_map(self):
        return self.__world_map

    @property
    def dictionary_of_map_numba(self):
        return self.__world_map_numba

    def draw(self):
        #  Для каждого значение в нашем словарике отрисовываем квадратик - как я уже писал - маштабируем его при этом!!!
        [pg.draw.rect(self.__game.screen, 'white', (pos[0] * game_scale, pos[1] * game_scale, game_scale, game_scale), 2)
         for pos in self.__world_map]