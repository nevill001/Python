#  настройки экрана
import os
import math

screen_wight, screen_height = 1280, 720
fps = 0
game_scale = 100
half_of_screen_wight = screen_wight // 2
half_of_screen_height = screen_height // 2

#  Настройки игрока
player_start_position = (5.5, 5.5)
player_angle = 0
player_rotate_speed = 4e-3
player_speed = 2e-3
player_radius = 0.4
player_size_scale = player_radius * game_scale
player_health = 100

#  Настройки мыши
mouse_border_left = 100
mouse_border_right = screen_wight - mouse_border_left
mouse_max_rel = 60
mouse_sensivity = 3e-4

#  Настройки лучей
angle_of_wiev = math.pi / 3
#  Уменьшаяем вдвое количество лучей для увеличения производительности
num_of_rays = screen_wight // 2
angle_between_rays = angle_of_wiev / num_of_rays
# максимальная дальность отрисовки - 20 блоков, это максимальная дальность на которую могут проникать наши лучи
max_depth = 20

#  Настройки "3д" отрисовки
screen_dist = half_of_screen_wight / math.tan(angle_of_wiev / 2)
screen_scale = screen_wight // num_of_rays

#  Наложения текстур
texture_size = 400

#  Пути  к графическим файлам игры
path_to_level_map = os.path.abspath(os.path.join('level.txt'))
path_to_resources = os.path.abspath(os.path.join('venv', 'resources'))
path_to_sprites = os.path.abspath(os.path.join('venv', 'resources', 'objects'))
path_to_npc = os.path.abspath(os.path.join('venv', 'resources', 'npc'))
path_to_weapon = path_to_resources + '\\weapon_shotgun'
path_to_sounds = path_to_resources + '\\sounds\\'

if __name__ == '__main__':
    print(path_to_npc)
    print(os.listdir(path_to_npc))
