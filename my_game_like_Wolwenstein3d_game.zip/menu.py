#  Импорты основных библиотек
import pygame as pg
import re
from collections import deque
#  Импорты вспомогательных библиотек и системных утилит
import sys
import os
#  Импортируем наш основном файл игры
from main import Game


class MainRoot:
    def __init__(self):
        #  Тут хранятся данные для настроек
        self.__settings_dict = self.settings_dict()
        #  Основные настройки экрана
        self.__screen_width = self.__settings_dict.get('root_screen_width', 1280)
        self.__screen_height = self.__settings_dict.get('root_sreen_height', 720)
        self.__fps = self.__settings_dict.get('fps', 60)
        self.delta_time = 1
        #  Блок с глобальными переключателями
        self._program_switcher = False
        self.__menu_counter = 1
        #  Тут хранится уровень вложености программы, и само меню в виде списков
        self.__menu_list = self.__get_menu_list()
        self.__list_level_counter = deque()
        self.__list_level_counter.append(self.__menu_list)
        #  Выполняем сразу загрузку файла с настройками если есть и перезаписываем найстроки программы
        self.__settings()
        #  Инициализируем модуль pygame
        pg.init()
        self.__screen = pg.display.set_mode((self.__screen_width, self.__screen_height))
        self.__clock = pg.time.Clock()
        #  Запускаем программу
        self.__run_program()

    @property
    def return_screen(self):
        return self.__screen

    @property
    def return_clock(self):
        return self.__clock

    @property
    def return_fps(self):
        return self.__fps

    def __current_menu(self):
        current_list = self.__list_level_counter[-1]
        result_list = list()
        for item in current_list:
            if isinstance(item, str):
                result_list.append(item)
            elif isinstance(item, list):
                result_list.append(item[0])
            elif isinstance(item, dict):
                result_list.append(list(item.keys())[0])
        return result_list

    def _draw_menu(self):
        font_size_1 = 42
        font_size_2 = font_size_1 - 10
        font_1 = pg.font.SysFont('comicksans', font_size_1)
        font_2 = pg.font.SysFont('comicksans', font_size_2)
        step = self.__screen_height // 3
        self.__current_list = self.__current_menu()
        for index, item in enumerate(self.__current_list):
            if index == 0:
                text = font_1.render(f'{item}', True, (50, 50, 50))
                self.__screen.blit(text, (self.__screen_width // 3, step))
            elif index == self.__menu_counter:
                text = font_2.render(f'{item}', True, (90, 90, 90))
                self.__screen.blit(text, (self.__screen_width // 3, step))
            else:
                text = font_2.render(f'{item}', True, (40, 40, 40))
                self.__screen.blit(text, (self.__screen_width // 3, step))
            step += (font_size_2) + font_size_2 // 3

    def __control_menu(self):
        lenght_current_menu = len(self.__list_level_counter[-1]) - 1
        key_listener = pg.key.get_pressed()
        self.__menu_counter = max(min(self.__menu_counter, lenght_current_menu), 1)
        if key_listener[pg.K_UP]:
            self.__menu_counter -= 1
        if key_listener[pg.K_DOWN]:
            self.__menu_counter += 1
        if key_listener[pg.K_RETURN]:
            if isinstance(self.__list_level_counter[-1][self.__menu_counter], list):
                self.__list_level_counter.append(self.__list_level_counter[-1][self.__menu_counter])
            elif isinstance(self.__list_level_counter[-1][self.__menu_counter], dict):
                list(self.__list_level_counter[-1][self.__menu_counter].values())[0]()
        if key_listener[pg.K_ESCAPE]:
            self.__list_level_counter.pop()

    def __update(self):
        self.__control_menu()
        pg.display.flip()
        self.__clock.tick(15)
        pg.display.set_caption(f'{self.__clock.get_fps()} :.1f')

    def __draw(self):
        #  Основные велечины
        self.__screen.fill('black')
        self._draw_menu()

    def __run_program(self):
        while not self._program_switcher:
            for event in pg.event.get():
                if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE and len(self.__list_level_counter) < 2):
                    self.__quit()
            self.__update()
            self.__draw()

    @staticmethod
    def settings_dict():
        dict = {
            'root_screen_width': 1280,
            'root_sreen_height': 720,
            'fps': 60
        }
        return dict

    def __update_class(self):
        self.__screen_width = self.__settings_dict.get('root_screen_width', 1280)
        self.__screen_height = self.__settings_dict.get('root_sreen_height', 720)
        self.__fps = self.__settings_dict.get('fps', 60)

    def __settings(self):
        try:
            with open('.\\settings.txt', 'r') as file:
                src = file.readlines()
                for line in src:
                    find_elem = False
                    for elem in self.__settings_dict.keys():
                        find_elem = re.findall(elem, line)
                        if find_elem:
                            value = re.findall(f'\d+', line)
                            self.__settings_dict[find_elem[0]] = int(value[0])
                            break
            self.__update_class()
        except FileNotFoundError:
            with open('.\\settings.txt', 'w+') as file:
                self.__settings()

    def __quit(self):
        pg.quit()
        sys.exit()

    def __back(self):
        self.__list_level_counter.pop()

    def show_parametrs_for_debaging(self):
        return self.__screen_width, self.__screen_height

    def __get_menu_list(self):
        return[
            'Main menu', [
                'Nested menu',
                {'Level_1': self.__run_program_1},
                {'Level_2': self.__run_program_2},
                {'Level_3': self.__run_program_3},
                {'Back': self.__back}
            ], {'Quit': self.__quit}
        ]

    def __run_program_1(self):
        new_game = Game(self, (5.5, 5.5), os.path.abspath(os.path.join('level.txt')))
        new_game.run()
        self._program_switcher = True

    def __run_program_2(self):
        new_game = Game(self, (2.5, 2.5), os.path.abspath(os.path.join('level_2.txt')))
        new_game.run()
        self._program_switcher = True

    def __run_program_3(self):
        new_game = Game(self, (2.5, 2.5), os.path.abspath(os.path.join('level_3.txt')))
        new_game.run()
        self._program_switcher = True


if __name__ == '__main__':
    object = MainRoot()