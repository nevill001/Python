import functools
import random
from card import Card
import os


class Deck:  # Класс игральной колоды. Он инициализируется с помощью ипортированного модуля card и класса внутри него Card
    def __init__(self):
        self.cards = [] # Создается игральная колода карт из карт класса Card
        for suite in range(4):
            for ranks in range(9):
                self.cards.append(Card(ranks, suite, trump=0))

    def shuffle(
            self):  # Метод для тусувания колоды карт, возвращает тусованную колоду карт, после этого этот объект перестает быть классом и становится списком
        for index in range(len(self.cards)):
            random_index = random.randrange(len(self.cards))
            self.cards[index], self.cards[random_index] = self.cards[random_index], self.cards[index]
        return self.cards

    def __str__(
            self):  # Метод __str__ используется для отображение содержимого класса в ружиме строки
        # !!!(в даной программе не используется)!!!
        l_1 = []
        for i in range(len(self.cards)):
            l_1.append(self.cards[i])
        s = ' '.join(str(l_1[i]) for i in range(len(l_1)))
        return s


def main(deck, player_1, player_2, trump, line_1=[], line_2=[]):
    counter = 0  #Счетчик ходов

    def win():
        nonlocal player_1
        nonlocal player_2
        nonlocal line_1
        nonlocal line_2
        nonlocal trump
        nonlocal deck
        nonlocal counter
        print(f'ХОДОВ СДЕЛАНО {counter}')
        if len(player_1) == 0 and len(player_2) != 0:
            print('Player number 1 - WIN')
        if len(player_1) != 0 and len(player_2) == 0:
            print('computer - WIN')
        if len(player_1) == 0 and len(player_2) == 0:
            print('DRAW - НИЧЬЯ!')

    def display(): # Эта функция нужна для отображения информации
        nonlocal player_1
        nonlocal player_2
        nonlocal line_1
        nonlocal line_2
        nonlocal trump
        nonlocal deck
        os.system('cls')
        print('')
        print(f'Trump of deck is \33[48;5;230m({Card.suits[trump]})\33[0;0m card in deck are \33[48;5;230m({len(deck)})\33[0;0m')
        print('')
        print('card of player 2: ', end='')
        print(', '.join(f'\33[48;5;88m{str(player_2[i])}\33[0;0m' for i in range(len(player_2))))
        print('table of plater 2:', end='')
        print(', '.join(f'\33[48;5;126m{str(line_2[i])}\33[0;0m' for i in range(len(line_2))))
        print('table of plater 1:', end='')
        print(', '.join(f'\33[48;5;26m{str(line_1[i])}\33[0;0m' for i in range(len(line_1))))
        print('card of player 1: ', end='')
        print(', '.join(f'{i + 1} = \33[48;5;19m{str(player_1[i])}\33[0;0m' for i in range(len(player_1))))

    def decorators_mistake(func):  #Декортаор для устранения и отлова ошибок ввода
        nonlocal player_1
        nonlocal player_2
        nonlocal line_1
        nonlocal line_2
        nonlocal counter

        def nested_funck():
            nonlocal player_1
            nonlocal player_2
            nonlocal line_1
            nonlocal line_2
            nonlocal counter
            flag = 0
            while flag == 0:  #Пока фгал не будет -1 или 1, это означает что функция удачно завершила рботу, будет идти проверка
                    flag = func  #Получение значения функции
            return flag
        return nested_funck()

    def card_distribution(player): # Функция для раздачи карт игрокам
        nonlocal deck
        if len(deck) != 0: #Провенка что в колоде есть еще Карты
            if len(player) < 6 and len(deck) != 0: #
                for item in range(6 - len(player)):
                    card = deck.pop(random.randrange(len(deck)))
                    player.append(card)
        return player

    @decorators_mistake  #Этот декоратор применен для перезагрузки фунции если возникла ошибка, хотя вроже и без него должно работать...
    # Там же условия есть. Это сделано для понимания сути декораторов... Данные из функции не должны терятся ведь они не локальны
    def player_turn():
        nonlocal player_1
        nonlocal player_2
        nonlocal line_1
        nonlocal line_2
        nonlocal counter
        try:
            while len(player_1) != 0:
                display()
                message = input('YOUR TURN -->> ')  #Пользователь выбирает карту
                if message == 'stop' and len(line_1) > len(line_2):
                    return -1  # Игрок соглашен на то что добавлять он больше не хочет и ждет ответа оппонента
                if message == 'next':  #Кмоанда для передачи хода оппоненту
                    counter += 1
                    return 1 #добавлять больше нечего, ход передается оппоненту
                choise = int(message) - 1  #Перевод выбранного номера в числовое значение, и отнятие еденицы, чтобы получить номер элемента в списке
                if len(line_1) == 0:  #Если стол игрока пустой, можно добавлять любую карту
                    item_card = player_1.pop(choise)  #Удаление и получение карты из списка карт игрока
                    line_1.append(item_card)  #Карта добавляется на стол
                else:  #Если стол игрока полый то можно добавить карту только того номинала что и на столе
                    for item in line_1:  #Идем циклом по каждой карте на столе игрока
                        if item.rank == player_1[choise].rank:
                            item_card = player_1.pop(choise)  #Если номинал карты совпадает с выбранным то карта добавляется на стол
                            line_1.append(item_card)
                            break  #Прерывание цикла, дальше идти нету смысла
                    for item in line_2:  #Точно также проходим по столу оппоента
                        if item.rank == player_1[choise].rank:
                            item_card = player_1.pop(choise)
                            line_1.append(item_card)
                            break
        except IndexError:  #Перехват ошики если введено неверное число карты
            print(f'\33[38;5;196m !!!Enter Wrong Number of card!!! Try again. \33[0;0m')
            return 0
        except ValueError:  #Перехват ошибки если пользователь вводит неверную команду
            print(f'\33[38;5;196m !!!Enter Wrong Command!!! Type -stop if y wond to continue/ type -next if y wont to give the turn to computer Try again. \33[0;0m')
            return 0
        except Exception:
            print(f'\33[38;5;196m !!!Enother MISTAKE!!! Try again. \33[0;0m')
            return 0

    def computer_response(): #Игрок сделал ход и теперь ходит компьюетр
        nonlocal player_1
        nonlocal player_2
        nonlocal line_1
        nonlocal line_2
        while len(line_2) < len(line_1):  #Компьютер отвечает до тех пор пока его игровой стол меньше чем игровой стол игрока.
            # Тоесть игрок выставил небитые карты
            for i in range(len(line_2), len(line_1)):  #Тут цикл начинается как раз с небитых карт! Если такие имеются,
                # или идет с самого начала списка
                item_suit = line_1[i].suit  #Получает характеристики карты, что стоит на пизиции и-той в списке на столе игроке
                item_rank = line_1[i].rank
                item_trump = line_1[i].trump
                player_2_list = list(filter(lambda x: x.suit == item_suit, player_2))  #Ищет в своих "руках" карты такойже масти
                if len(player_2_list) != 0:  #Если список не пуст, идет дальше
                    card_of_line = functools.reduce(lambda x, y: x if item_rank < x.rank < y.rank else y, player_2_list)  #Ищет самую наименьшую карту которой может отбится
                    if card_of_line.rank > item_rank:
                        player_2.remove(card_of_line)
                        line_2.append(card_of_line)
                    else:  # В противном случае ищет козырь
                        player_2_list = list(filter(lambda x: x.trump == 1, player_2))
                        if len(player_2_list) != 0 and item_trump != 1:
                            card_of_line = functools.reduce(lambda x, y: x if x.rank < y.rank else y, player_2_list)
                            player_2.remove(card_of_line)
                            line_2.append(card_of_line)
                        else:  # Если нету козыря, берет карты себе, флаг помечен как -1!!! Ходит опять игрок
                            player_2 += line_1
                            player_2 += line_2
                            line_1.clear()
                            line_2.clear()
                            return -1  # Компьютер взял карту, флаг помечен как -1 = опять ход игрока
                else:  #В противном случае ищет козырь
                    player_2_list = list(filter(lambda x: x.trump == 1, player_2))
                    if len(player_2_list) != 0 and item_trump != 1:
                        card_of_line = functools.reduce(lambda x, y: x if x.rank < y.rank else y, player_2_list)
                        player_2.remove(card_of_line)
                        line_2.append(card_of_line)
                    else:  #Если нету козыря, берет карты себе, флаг помечен как -1!!! Ходит опять игрок
                        player_2 += line_1
                        player_2 += line_2
                        line_1.clear()
                        line_2.clear()
                        return -1  # Компьютер взял карту, флаг помечен как -1 = опять ход игрока
        return 1  # Компьютер отбил карту - своей картой, флаг на Еденице, если игрок ничего не добавит то следущий ход ходит компьютер

    def computer_turn(): # Компьютер ходит а игрок потом должен ответить
        nonlocal player_1
        nonlocal player_2
        nonlocal line_1
        nonlocal line_2
        if len(line_1) == 0:  #КОМЬЮТЕР НАЧИНАЕТ ХОДИТЬ, ИГРОК ЕЩЕ НЕ ОТВЕЧАЛ
            list_player_2 = list(filter(lambda x: x.trump != 1, player_2))  #КОМПЬЮТЕР ИЩЕТ НЕ КОЗЫРЬ
            if len(list_player_2) != 0:
                item_card = functools.reduce(lambda x, y: x if x.rank < y.rank else y, list_player_2)  #ВИБРАЕТ НАИМЕНЬШИЙ РАНГ
                line_2.append(item_card)
                player_2.remove(item_card)
            else:
                if len(player_2) != 0:
                    item_card = functools.reduce(lambda x, y: x if x.rank < y.rank else y, player_2)  #УЖЕ ГОТОВ КИНУТЬ И КОЗЫРЬ
                    line_2.append(item_card)
                    player_2.remove(item_card)
            list_player_2 = list(filter(lambda x: x.rank == item_card.rank, player_2))  #ДОКИДЫВАЕТ КАРТЫ ТАКОГО ЖЕ НОМИНАЛА ЧТО ПОЛОЖИЛ
            if len(list_player_2) != 0:
                line_2 += list_player_2
                for i in range(len(list_player_2)):
                    player_2.remove(list_player_2[i])
            return 0
        else:
            for item in range(len(line_1)):  #КОМИЬЮЕТР ИЩЕТ КАРТЫ ЧТОБЫ ПОДКИНУТЬ, НО ПРЕРЕГАТИВУ ОТДАЕТ НЕ КОЗЫРЯМ
                list_player_2 = list(filter(lambda x: x.rank == item.rank and item.trump != 1, player_2))
                if len(list_player_2) != 0:
                    line_2 += list_player_2
                    for i in range(len(list_player_2)):
                        player_2.remove(list_player_2[i])
                else:  #КОМПЬЮЕТР НЕ НАШЕЛ ЧТО ПОДКИНУТЬ И ПОДКИДЫВАЕТ КОЗЫРЬ
                    list_player_2 = list(filter(lambda x: x.rank == item.rank, player_2))
                    if len(list_player_2) != 0:
                        if len(list_player_2) != 0:
                            line_2 += list_player_2
                            for i in range(len(list_player_2)):
                                player_2.remove(list_player_2[i])
            if len(line_2) == len(line_1):
                return 1  #ДЛИНА СТОЛА ОДИНАКОВА, КОМПЬЮТЕР НЕ НАШЕЛ ЧТО ПОДКИНУТЬ, ХОД ПЕРЕДАЕТСЯ ИГРОКУ!
            else:
                return -1

    @decorators_mistake
    def player_response():
        nonlocal player_1
        nonlocal player_2
        nonlocal line_1
        nonlocal line_2
        try:
            while len(line_1) != len(line_2):
                for i in range(len(line_1), len(line_2)):
                    display()
                    message = input('YOUR RESPONSE -->> ')
                    if message == 'take':
                        player_1 += line_2
                        player_1 += line_1
                        line_2.clear()
                        line_1.clear()
                        return -1
                    else:
                        choise = int(message) - 1
                        if (player_1[choise].suit == line_2[i].suit and player_1[choise].rank > line_2[i].rank):
                            item_card = player_1.pop(choise)
                            line_1.append(item_card)
                        if (player_1[choise].trump == 1 and line_2[i].trump != 1):
                            item_card = player_1.pop(choise)
                            line_1.append(item_card)
            return 1
        except IndexError:
            print(f'\33[38;5;196m !!!Enter Wrong Number of card!!! Try again. \33[0;0m')
            return 0
        except ValueError:
            print(
                f'\33[38;5;196m !!!Enter Wrong Command!!! Type -take if y wont to take the card. Try again. \33[0;0m')
            return 0
        except Exception:
            print(f'\33[38;5;196m !!!Enother MISTAKE!!! Try again. \33[0;0m')
            return 0


    while len(deck) != 0 and len(player_1) != 0 or player_2 != 0: #!!!!! ИГРА НАЧИНАЕТСЯ ОТ СЮДА!!!!
        # игра идет до тех пор пока не выполнится условие: (колода пуста и одного из игроков тоже нету карт)
        player_1 = card_distribution(player_1) # игроки получают карты
        player_2 = card_distribution(player_2)
        line_1.clear() # "игровой стол" отчищается
        line_2.clear()
        number_1 = 0 # Флаги в нулевых состояниях
        number_2 = 0
        while number_1 != 1:  # Это часть кода выполняется до тех пор пока компьютер не отобьет карты
            # а игрок не согласится что больше добавить не может
            number_1 = player_turn()  #Ход делает игрок
            number_2 = computer_response()  #Кмоптьютер отвечает
            if number_2 == -1:
                player_1 = card_distribution(player_1)
                player_2 = card_distribution(player_2)
            if len(deck) == 0 and len(player_1) == 0 or len(player_2) == 0: # Проверка на то что у игрока 1 - есть еще карты
                # на случай если карт в колоде не осталось
                break
        if len(deck) == 0 and len(player_1) == 0 or len(
                player_2) == 0:  # Проверка на то что у игрока 1 - есть еще карты
            # на случай если карт в колоде не осталось
            break
        line_1.clear() # Игровой стол очищается
        line_2.clear()
        player_1 = card_distribution(player_1)  # Теперь все тоже самое но теперь ход делает компьютер
        player_2 = card_distribution(player_2)
        number_1 = 0
        number_2 = 0
        while number_1 != 1 and number_2 != 1:  # ЕСЛИ Условия выпонены Ход передается опять гроку
            number_1 = computer_turn()  #Ход делает компьютер
            number_2 = player_response()  #Игрок отвечает
            if number_2 == -1:
                player_1 = card_distribution(player_1)
                player_2 = card_distribution(player_2)
            if len(deck) == 0 and len(player_1) == 0 or len(player_2) == 0:  # Проверка на то что у игрока 1 - есть еще карты
                # на случай если карт в колоде не осталось
                break
        if len(deck) == 0 and len(player_1) == 0 or len(player_2) == 0:
            break

    win()  #ВЫЗЫВ ФУНЦИИ НАГРАЖДЕНИЯ


if __name__ == '__main__':  # это ТОЧКА СТАРТА программы. Запустится только в тому случае если этот файл запущен
    # как основной а не как импортированный модуль
    deck = Deck().shuffle()  # получаем колоду из класса Deck состоящую из объектов карта - класса Card.
    # После этого этот объект больше не является классом и является списком
    # и к нему можно применять методы роботы со списками
    # С помощью метода shuffle из класса Deck тусуем колоду случайным образом
    trump = random.randrange(4) # Выбираем случайный козырь
    for j in range(len(deck)):
        if deck[j].suit == trump:
            deck[j].trump = 1
    player_1 = []  # это "руки" игрока
    player_2 = []  # это "руки" игрока комптьютера
    main(deck, player_1, player_2, trump)  # Передаем тусованную колоду и пустые пока списки в основную программу
