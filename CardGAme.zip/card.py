class Card:
    rank_upper = ['Jack', 'Queen', 'King', 'Ace', 'J_black', 'J_red']
    rank_lower = [str(i) for i in range(6, 11)]
    ranks = rank_lower + rank_upper[:4]
    suits = ['Clubs', 'Spades', 'Diamonds',
             'Hearts']

    def __init__(self, rank=0, suit=0, trump=0):
        self.rank = rank
        self.suit = suit
        self.trump = trump

    # def __cmp__(self, other):
    #     if self.trump > other.trump:
    #         return 1
    #     if self.trump < other.trump:
    #         return -1
    #     if self.rank > other.rank:
    #         return 1
    #     if self.rank < other.rank:
    #         return -1

    def __str__(self):
        return f'{self.ranks[self.rank]} of {self.suits[self.suit]}'